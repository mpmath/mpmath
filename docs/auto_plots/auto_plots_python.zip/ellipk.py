"""
Complete elliptic integrals `K(m)` and `E(m)`.
-------------------------------------------------
"""
from mpmath import *
plot([ellipk, ellipe], [-2,1], [0,3], points=600)
