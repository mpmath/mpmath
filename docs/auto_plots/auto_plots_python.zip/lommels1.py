"""
Lommel function `s_{(u,v)}(x)` on the real line for a few different `u`,`v`.
-----------------------------------------------------------------------------
"""
from mpmath import *
f1 = lambda x: lommels1(-1,2.5,x)
f2 = lambda x: lommels1(0,0.5,x)
f3 = lambda x: lommels1(0,6,x)
f4 = lambda x: lommels1(0.5,3,x)
plot([f1,f2,f3,f4], [0,20])
