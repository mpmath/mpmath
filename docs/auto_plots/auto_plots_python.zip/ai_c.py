"""
Airy function `Ai(z)` in the complex plane.
-------------------------------------------
"""
from mpmath import *
cplot(airyai, [-8,8], [-8,8], points=50000)
